<?php

try {
    // Attempt to establish a connection
    $conn = mysqli_connect("localhost", "arcuin", "TrPpa#@p7lra?lbrxxx", "arcuin_Dailogues_media");

    // Check connection
    if (!$conn) {
        throw new Exception("Failed to connect to the database: " . mysqli_connect_error());
    }
} catch (Exception $e) {
    // Handle the exception (display an error message)
    echo "Connection failed: " . $e->getMessage();
}

?>