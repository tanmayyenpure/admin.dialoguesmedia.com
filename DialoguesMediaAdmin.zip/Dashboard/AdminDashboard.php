<?php
session_start();
if (!isset($_SESSION["AdminLoginId"])) {
    header("location: ../AdminLogin.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="../css/style.css">

	<title>Admin Dashboard</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<img src="../img/apple-touch-icon.png" alt="">
			<span class="text">Dialoguesmedia</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
            <a href="">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
            <li class="has-submenu">
        <a href="#">
            <i class='bx bxs-megaphone'></i>
            <span class="text">Marketing</span>
        </a>
        <ul class="submenu">
        <li><a href="../Dashboard/MarketingProjects.php">
            <span class="text" style="text-align: center;padding-left: 20px;">My Projects</span>
        </a>
        </li>
        <li><a href="../Project/ProjectListing.php">
            <span class="text" style="text-align: center;padding-left: 20px;">New Project</span>
        </a></li>
            <!-- Add more sub-items as needed -->
        </ul>
   			</li>
		</ul>
		<ul class="side-menu">
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Search here</a>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>

			<a href="#" class="profile">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Dashboard</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Dashboard</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="#" href="#">Home</a>
							<!--<a class="active" href="#">Home</a>-->
						</li>
					</ul>
				</div>
			</div>
<div style="display:none;">
			<ul class="box-info">
				<li>
					<i class='bx bxs-calendar-check' ></i>
					<span class="text">
						<h3><a href="./empID.html">Project-1</a></h3>
						<!-- <p>Project1</p> -->
					</span>
				</li>
				<li>
					<i class='bx bxs-calendar-check' ></i>
					<span class="text">
						<h3><a href="dddd.htm">Project-2</a></h3>
						<!--<p>Project2</p>-->
					</span>
				</li>
				<li>
					<i class='bx bxs-calendar-check'></i>
					<span class="text">
						<h3><a href="./home.html">Project-3</a></h3>
						<!-- <p>Project3</p>-->
					</span>
				</li>
			</ul>
</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
</body>
</html>