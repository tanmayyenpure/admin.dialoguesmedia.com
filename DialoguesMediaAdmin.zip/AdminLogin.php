<?php
require("formconnection.php")
?>

<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./css/form.css">
  <title>Admin Login</title>
</head>

<body>
  <div class="popup" id="popup-1">

    <div class="content">

      <div class="close-btn"></div>
      <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>">
        <h1>Admin Login</h1>
        <div class="input-field">
          <input placeholder="user'Id " class="validate" name="adminName">
        </div>
        <div class="input-field">
          <input placeholder="Password"  type="password" class="validate" name="adminPassword">
        </div>

        <button class="second-button" type="submit" name="login">Login</button>

        <p><a href="/signup.html">Forgot-Password</a></p>
      </form>
    </div>

  </div>

  <?PHP

  function input_filter($data){
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
  } 
  if(isset($_POST['login'])){
    $Adminname=input_filter($_POST['adminName']);
    $Adminpass=input_filter($_POST['adminPassword']);

    $Adminname=mysqli_real_escape_string($conn,$Adminname);
    $Adminpass=mysqli_real_escape_string($conn,$Adminpass);
    $query="SELECT * FROM `adminlogin` WHERE `user_id`=? AND `user_password`=?";

    if($stmt=mysqli_prepare($conn,$query))
    {
      mysqli_stmt_bind_param($stmt,"ss", $Adminname, $Adminpass);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_store_result($stmt);
      if(mysqli_stmt_num_rows($stmt)== 1)
      {
        session_start();
        $_SESSION["AdminLoginId"]=$Adminname;
        header("location: Dashboard/AdminDashboard.php");
      }
      else{
        echo "<script>alert('invalid admin Name and Password')</script>";
      }
      mysqli_stmt_close($stmt);
    }
    else
    {
      echo "<script>alert('not preapared')</script>";
    } 
  }

  ?>
</body>
</html>
</html>