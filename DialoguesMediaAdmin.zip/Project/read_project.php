<?php
include '../formconnection.php';
header('Content-Type: application/json');
try {
    if (isset($_GET['project_id'])) 
    {
        $project_id = $_GET['project_id'];
        $sql = "SELECT * FROM projects WHERE project_id = '$project_id'";
    } 
    else 
    {
        $project_id = ''; 
        $sql = "SELECT * FROM projects";// Set a default value or leave it empty for all projects
    }
   
    $result = $conn->query($sql);
    $projects = array();

    if ($result->num_rows > 0) {
        if ($result->num_rows == 1) 
        {
            $projects = $result->fetch_assoc();
        }
        else
        {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
        }
    }

    echo json_encode(array('status' => 'success', 'data' => $projects));
} catch (Exception $e) {
    echo json_encode(array('status' => 'error', 'message' => 'Caught exception: ' . $e->getMessage()));
}

$conn->close();
?>
