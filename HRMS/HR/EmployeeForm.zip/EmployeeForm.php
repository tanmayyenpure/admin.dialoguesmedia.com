<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1024, initial-scale=0.1, user-scalable=yes">
    <link rel="stylesheet" href="../Template/css/bootstrap.min.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/style.css">
    <link href="../Template/vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">
    <title>Employee Form</title>
</head>

<body>

    <!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand">
			<img src="../img/apple-touch-icon.png" alt="">
			<span class="text">Dialoguesmedia</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
            <a href="../Dashboard/AdminDashboard">
					<i class='bx bxs-dashboard' ></i>
					<span class="text">Dashboard</span>
				</a>
			</li>
            <li class="has-submenu">
        <a href="#">
            <i class='bx bxs-megaphone'></i>
            <span class="text">Marketing</span>
        </a>
        <ul class="submenu">
        <li><a href="../Dashboard/MarketingProjects.php">
            <span class="text" style="text-align: center;padding-left: 20px;">My Projects</span>
        </a>
        </li>
        <li><a href="../Project/ProjectListing.php">
            <span class="text" style="text-align: center;padding-left: 20px;">New Project</span>
        </a></li>
            <!-- Add more sub-items as needed -->
        </ul>
   			</li>
		</ul>
		<ul class="side-menu">
		</ul>
	</section>
	<!-- SIDEBAR -->
    <!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="#" class="nav-link">Search here</a>
			<form action="#">
				<div class="form-input">
					<input type="search" placeholder="Search...">
					<button type="submit" class="search-btn"><i class='bx bx-search' ></i></button>
				</div>
			</form>

			<a href="#" class="profile">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
        <div class="popup" id="popup-2">
        <div class="content">
            <div class="close-btn"></div>
            <div class="card shadow mb-4">
            <div class="card-header py-3  d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-danger fs-30">Employee</h6>
                <div class="d-flex">
                <a href="EmployeeListing.php" class="btn btn-danger btn-circle" data-toggle="tooltip" data-title="Employee Listing">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                </div>
            </div>
            <div class="card-body">
            <form id="EmployeeForm">
                <div class="form-group">
                    <label for="emp_id">Employee ID</label>
                    <input type="text" placeholder="Employee-Id" id="emp_id" class="form-control" name="emp_id" required readonly>
                </div>

                <div class="form-group">
                    <label for="name">Name *</label>
                    <input type="text" placeholder="Name" id="name" class="form-control" name="name" required>
                </div>

                <div class="form-group">
                    <label for="aadhar_card_no">Aadhar Card Number *</label>
                    <input type="text" placeholder="Aadhar Card Number" id="aadhar_card_no" class="form-control" name="aadhar_card_no" maxlength="12" required>
                </div>

                <div class="form-group">
                    <label for="pan_card">PAN Card</label>
                    <input type="text" placeholder="PAN Card" id="pan_card" class="form-control" name="pan_card">
                </div>

                <div class="form-group">
                    <label for="mobile_number">Mobile Number</label>
                    <input type="text" placeholder="Mobile Number" id="mobile_number" class="form-control" name="mobile_number" maxlength="15">
                </div>

                <div class="form-group">
                    <label for="department_name">Department Name *</label>
                    <select id="department_name" class="form-control" name="department_name" onchange="handleDepartmentChange()">
                    <option value="Human Resources">Human Resources</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Sales">Sales</option>
                    <option value="Web">Web</option>
                    <option value="Others">Others</option>
                                        </select>
                </div>

                <div class="form-group" id="projectGroup" style="display:none;">
                    <label for="project_id">Project *</label>
                    <select id="project_id" class="form-control" name="project_id">
                        <!-- Add more projects as needed -->
                    </select>
                </div>

                <div class="form-group">
                    <label for="job_role">Job Role</label>
                    <input type="text" placeholder="Job Role" id="job_role" class="form-control" name="job_role">
                </div>
                <?php
                    $buttonText = isset($_GET['emp_id']) ? 'Update Employee' : 'Add Employee';
                    $onClickFunction = isset($_GET['emp_id']) ? 'updateForm()' : 'submitForm()';

                    // Add a condition for delete
                    if (isset($_GET['emp_id']) && isset($_GET['delete'])) {
                        $onClickFunction = 'deleteForm()';
                        $buttonText = 'Delete Employee';
                    }
                ?>
                <button class="btn btn-danger" type="button" onclick="<?php echo $onClickFunction; ?>; resetFormValues(); location.reload();">
                    <?php echo $buttonText; ?>
                </button>
            </form>
            </div>
            </div>
        </div>

         <div class="container-fluid">
            <div class="card shadow mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-danger fs-15">Employees List</h6>
                    <!-- <div class="d-flex">
                        <a href="EmployeeForm.php" class="btn btn-danger btn-circle" data-toggle="tooltip" data-title="Create New Employee">
                            <i class="fas fa-plus"></i>
                        </a>
                    </div> -->
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table id="employeeTable" class="table table-bordered">
    <thead>
        <tr class="table-header" style="text-align:center;">
            <th>Emp_ID</th>
            <th>Name</th>
            <th>Adhar Card No.</th>
            <th>Pan Card No.</th>
            <th>Contact</th>
            <th>Department Name</th>
            <th>Job Role</th>
            <th >Action</th> 
        </tr>
    </thead>
    <tbody>
        <!-- Data rows will be inserted here -->
    </tbody>
</table>

<!-- jQuery (CDN) -->



                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        </div>

        
        </div>
        
		</main>
		<!-- MAIN -->
	</section>

    
	<!-- CONTENT -->
    <?php
   function getNextEmployeeCode() 
   {
       // Read the query from the text file
       $queryFilePath = 'GetMaxCode.txt';
       $query = file_get_contents($queryFilePath);
   
       include '../formconnection.php'; // Include your database connection file
   
       $result = $conn->query($query);
   
       if ($result->num_rows > 0) {
           $row = $result->fetch_assoc();
           $maxCode = $row["max_code"];
           if ($maxCode == '0') {
               $nextCode = 'DM001';
           } else {
               $nextNumber = (int)substr($maxCode, 2) + 1;
               $nextCode = 'DM' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);
           }
           // Return the next code
           return $nextCode;
       }
   
       $conn->close();
   }
   function setEmployeeValues($emp_id)
   {
    try
    {
        $baseURL = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        $readEmployeeUrl = "$baseURL/read_employee.php?emp_id=$emp_id";
        $readEmployeeData = file_get_contents($readEmployeeUrl);
        $employeeData = json_decode($readEmployeeData, true);
        if ($employeeData['status'] === 'success') {
            // Set values in all fields using JavaScript
            echo "<script>
            document.getElementById('emp_id').value = '{$employeeData['data']['emp_id']}';
            document.getElementById('name').value = '{$employeeData['data']['name']}';
            document.getElementById('aadhar_card_no').value = '{$employeeData['data']['aadhar_card_no']}';
            document.getElementById('pan_card').value = '{$employeeData['data']['pan_card']}';
            document.getElementById('mobile_number').value = '{$employeeData['data']['mobile_number']}';
            document.getElementById('job_role').value = '{$employeeData['data']['job_role']}';
    
            var departmentTypeDropdown = document.getElementById('department_name');
            var projectDropdown = document.getElementById('project_id');
            var projectGroup = document.getElementById('projectGroup');
            var departmentTypeValue = '{$employeeData['data']['department_name']}';
            departmentTypeDropdown.value = departmentTypeValue !== 'null' ? departmentTypeValue : departmentTypeDropdown.options[0].value;
            projectGroup.style.display = (departmentTypeValue === '2') ? 'block' : 'none';
            // Set project_id dropdown value if department_name is 2
            if (departmentTypeValue === '2') {
                var projectValue = '{$employeeData['data']['project_id']}';
                // Set project_id dropdown value if it's not null, otherwise set the first option
                projectDropdown.value = projectValue !== 'null' ? projectValue : projectDropdown.options[0].value;
            }
        </script>";
        } else {
            echo "<script>alert('Error: Unable to fetch employee data');</script>";
        }
    }
    catch (Exception $e)    
    {
        echo "<script>alert('Error: Caught exception - " . $e->getMessage() . "');</script>";
    }
   }
   
   if (isset($_GET['emp_id'])) {
    $emp_id = $_GET['emp_id'];
    echo "<script>document.addEventListener('DOMContentLoaded', function () {
        editEmployee('$emp_id');
    });</script>";
}
 else {
    $emp_id = getNextEmployeeCode();
    echo "<script>document.getElementById('emp_id').value = '$emp_id';</script>";
    } 
    ?>
</body>
<script src="../Template/vendor/jquery/jquery.min.js"></script>
    <script src="../Template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
    <script src="../Template/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../Template/js/popper.min.js"></script>
    
   
<script>
     $(document).ready(function () {
    // Initialize DataTable
    $('[data-toggle="tooltip"]').tooltip();
    $.ajax({
    url: '../Project/read_project.php',
    type: 'GET',
    dataType: 'json',
    success: function (response) {
        if (response.status === 'success') {
            var projects = response.data;

            // Clear existing options in the select dropdown
            $('#project_id').empty();

            // Populate dropdown options
            projects.forEach(function (project) {
                $('#project_id').append($('<option>', {
                    value: project.pid,
                    text: project.Pname
                }));
            });
        } else {
            console.error('Error fetching data:', response.message);
        }
    },
    error: function (xhr, status, error) {
        console.error('AJAX Error:', status, error);
    }
});

    });



    function deleteEmployee(event, emp_id) {
    event.preventDefault(); // 🔥 Stops page reload

    if (confirm("Are you sure you want to delete this employee?")) {
        $.ajax({
            url: 'delete_employee.php',
            method: 'POST',
            data: { emp_id: emp_id },
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    alert(response.message);
                    location.reload(); 
                } else {
                    alert("Failed to delete: " + response.message);
                }
            },
            error: function (xhr) {
                console.error("Delete error:", xhr.responseText);
                alert("Something went wrong while deleting.");
            }
        });
    }
}

    function updateForm() {
    const form = document.getElementById('EmployeeForm');
    const formData = new FormData(form);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_employee.php', true);

    console.log("Raw Response:", xhr.responseText); 
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            try {
                const response = JSON.parse(xhr.responseText);
                if (xhr.status === 200 && response.status === 'success') {
                    alert(response.message);
                    form.reset();
                    location.reload();
                } else {
                    alert("Error: " + response.message);
                }
            } catch (e) {
                console.error("Invalid JSON response:", xhr.responseText);
                // alert("Something went wrong while updating the form.");
            }
        }
    };

    xhr.send(formData);
}

 
    function submitForm() {
    const form = document.getElementById('EmployeeForm');
    const formData = new FormData(form);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'create_employee.php', true);

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            try {
                const response = JSON.parse(xhr.responseText);
                if (xhr.status === 200 && response.status === 'success') {
                    alert(response.message);
                    form.reset(); // Reset form
                    location.reload();
                } else {
                    alert("Error: " + response.message);
                }
            } catch (e) {
                console.error("Invalid JSON response:", xhr.responseText);
                // alert("Something went wrong while submitting the form.");
            }
        }
    };

    xhr.send(formData);
}



     function resetFormValues() {
    var elements = [
        'emp_id','name', 'aadhar_card_no', 'pan_card', 'mobile_number', 
        'department_name', 'project_id', 'job_role'
    ];

    elements.forEach(function(elementId) {
        var element = document.getElementById(elementId);
        if (element) {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.value = ''; // Clear input and textarea fields
            } else if (element.tagName === 'SELECT') {
                element.selectedIndex = 0; // Reset to first option
            } else {
                element.innerText = ''; // Reset text content for other elements
            }
        }
    });

    // If using checkboxes or radio buttons, reset them too
    var checkboxes = document.querySelectorAll('input[type="checkbox"], input[type="radio"]');
    checkboxes.forEach(function(checkbox) {
        checkbox.checked = false;
    });
}


</script>

    <script>
function handleDepartmentChange() {
    const dept = document.getElementById("department_name").value;
    const projectGroup = document.getElementById("projectGroup");

    if (dept === "Web") {
        projectGroup.style.display = "block";
    } else {
        projectGroup.style.display = "none";
        document.getElementById("project_id").value = ""; // clear project_id
    }
}
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function () {
    // Load employees into the table
    loadEmployees();

  
// Load employee list
function loadEmployees() {
    $.ajax({
        url: 'getall_employees.php',
        method: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response.status === 'success') {
                let rows = '';
                response.data.forEach(function (emp) {
                    rows += `
                        <tr>
                            <td>${emp.emp_id}</td>
                            <td>${emp.name}</td>
                            <td>${emp.aadhar_card_no}</td>
                            <td>${emp.pan_card}</td>
                            <td>${emp.mobile_number}</td>
                            <td>${emp.department_name}</td>
                            <td>${emp.job_role}</td>
                           <td class="text-center" style="display:flex;">
                                <a href="?emp_id=${emp.emp_id}" class="btn btn-sm btn-warning edit-btn" data-id="${emp.emp_id}" onclick="editEmployee('${emp.emp_id}')" style="margin-right:5px;">
                                    <i class="fas fa-edit"></i>
                                </a>
                              <a href="#" class="btn btn-sm btn-danger" onclick="deleteEmployee(event, '${emp.emp_id}')">
                                  <i class="fas fa-trash-alt"></i>
                               </a>


                            </td>
                        </tr>
                    `;
                });
                $('#employeeTable tbody').html(rows);
            } else {
                alert("Failed to fetch employee data.");
            }
        },
        error: function (xhr) {
            console.error("Error:", xhr.responseText);
        }
    });
}
});
</script>

<script>
function editEmployee(emp_id) {
    $.ajax({
        url: 'getall_employees.php',
        method: 'GET',
        data: { emp_id: emp_id },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                const emp = response.data;

                $('#emp_id').val(emp.emp_id);
                $('#name').val(emp.name);
                $('#aadhar_card_no').val(emp.aadhar_card_no);
                $('#pan_card').val(emp.pan_card);
                $('#mobile_number').val(emp.mobile_number);
                $('#job_role').val(emp.job_role);
                $('#department_name').val(emp.department_name);

                if (emp.department_name === "Web") {
                    $('#projectGroup').show();
                    $('#project_id').val(emp.project_id);
                } else {
                    $('#projectGroup').hide();
                    $('#project_id').val('');
                }

                // Optional scroll to top of form
                $('html, body').animate({ scrollTop: 0 }, 'fast');
            } else {
                alert('Failed to fetch employee data: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            alert('An error occurred while fetching data.');
        }
    });
}
</script>


    
</html>

